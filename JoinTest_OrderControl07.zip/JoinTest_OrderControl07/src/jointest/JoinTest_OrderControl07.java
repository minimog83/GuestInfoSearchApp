package jointest;
import view.CustomerSearchFrame;
// 結合番号７
public class JoinTest_OrderControl07 {
	public static void main(String[] args) {
		// 項番１，２
		new CustomerSearchFrame();
		// 実行後，「ナカムラマイ」を入力して「検索」ボタンを押下
	}
}
